from scipy.stats import gaussian_kde
import numpy as np
from utilities import *
from cvxopt import matrix,solvers
import knnie 
from npeet import entropy_estimators as ee
def mi_kde(x,y,bw_method='scott'):
    
    '''
    x: n_samples x dim_x
    y: n_samples x dim_y
    bw_method: 'scott', 'silverman', scalar or a callable function
    
    '''
    
    x = x.T
    y = y.T
    xy = np.concatenate([x,y],axis=0)
    
    kde_x = gaussian_kde(x,bw_method=bw_method)
    kde_y = gaussian_kde(y,bw_method=bw_method)
    kde_xy = gaussian_kde(xy,bw_method=bw_method)
    
    logp_x = kde_x.logpdf(x)
    logp_y = kde_y.logpdf(y)
    logp_xy = kde_xy.logpdf(xy)
    
    return (logp_xy - logp_x - logp_y).mean()
task_id = int(sys.argv[1])
rholist = np.linspace(0,0.99,20)
rho = rholist[task_id]
p = 10
k = 20
n = 10000
N = n*p
mu = np.array([[0,0]])
sigma = np.array([[[1,rho],[rho,1]]])
GMS = GaussianMixtureSample(mu,sigma)
x = GMS.sample(N)

x1 = x[(n*0):(n*(0+1)),0].reshape([-1,1])
y1 = x[(n*0):(n*(0+1)),1].reshape([-1,1])
for i in range(p-1):
    i = i + 1
    xi = x[(n*i):(n*(i+1)),0].reshape([-1,1])
    yi = x[(n*i):(n*(i+1)),1].reshape([-1,1])
    x1 = np.concatenate((x1,xi),1)
    y1 = np.concatenate((y1,yi),1) 



mi_kde_hat = mi_kde(x1,y1)
mi_knnie = knnie.kraskov_mi(x1,y1,k=6)
mi_knnie_revised = knnie.revised_mi(x1,y1,k=6,q=2)
mi_ee = ee.mi(x1,y1,k=6)

classic_2d = dict()
classic_2d['mi_kde_hat'] = mi_kde_hat
classic_2d['mi_knnie'] = mi_knnie
classic_2d['mi_knnie_revised'] = mi_knnie_revised
classic_2d['mi_ee'] = mi_ee
classic_2d['rho'] = rho

np.save('classic_10d_%d'%task_id, classic_2d)
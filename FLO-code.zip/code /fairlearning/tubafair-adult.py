import sys
sys.path.append("../")
sys.path.append("../../../")
sys.path.append("../../")
sys.path.append("../../../../")
sys.path.append("../")
from aif360.datasets import BinaryLabelDataset
from aif360.datasets import AdultDataset
from aif360.metrics import BinaryLabelDatasetMetric
from aif360.metrics import ClassificationMetric
from aif360.metrics.utils import compute_boolean_conditioning_vector


# from aif360.algorithms.preprocessing.reweighing import Reweighing
from aif360.algorithms.preprocessing.optim_preproc_helpers.data_preproc_functions            import load_preproc_data_adult

from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler, MaxAbsScaler
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report

from IPython.display import Markdown, display
import matplotlib.pyplot as plt
import numpy as np

#from aif360.examples.common_utils import compute_metrics

from linear_fairness import *
from mi import *
import copy

class BilinearTUBANCE(nn.Module):
    def __init__(self,
         critic: nn.Module, 
         u_func: Optional[nn.Module] = None,
         K: Optional[int] = None,
         args: Optional[Dict] = None,
         cuda: Optional[int] = None) -> None:
        
        super(BilinearTUBANCE,self).__init__()
        self.critic = critic
        self.u_func = u_func
        self.K = K
    def forward(self, x, y,K=None):
        
        '''
        x:    n x p
        y:    n x d true
        y0:   n x d fake 
        '''
        if K is None:
            K = self.K 
#         g = self.critic(x, y)
#         g0 = self.critic(x, y0)
#         u  = self.u_func(x, y)
#         output = u + torch.exp(-u+g0-g) - 1
        output  = self.PMI(x,y,K)
        output = torch.clamp(output,-5,15)
        return output.mean()
    
    def MI(self, x, y, K=10):
        mi = 0
        for k in range(K):
            y0 = y[torch.randperm(y.size()[0])]
            mi += self.forward(x,y,y0)
            
        return -mi/K      
    def PMI(self, x, y, K=None):
        '''
        x:    n x p
        y:    n x d true
        y0:   n x d fake 
        '''

        if self.u_func is not None:
            # two func mode
            u  = self.u_func(x)
            if K is not None:
            
                for k in range(K-1):

                    if k==0:
                        y0 = y0
                        g0 = self.critic(x, y0)
                    else:
                        y0 = y[torch.randperm(y.size()[0])]
                        g0 = torch.cat((g0,self.critic(x, y0)),1)

                g0_logsumexp = torch.logsumexp(g0,1).view(-1,1)
                output = u + torch.exp(-u+g0_logsumexp-g)/(K-1) - 1
            else:               
                
                g = self.critic(x, y)
                g0 = self.critic(x, y0)
               
                output = u + torch.exp(-u+g0-g) - 1
        else:
            # one func mode
            gu = self.critic(x,y)
            if isinstance(gu, tuple):
                hx,hy,u = gu
                similarity_matrix = hx @ hy.t()
                pos_mask = torch.eye(hx.size(0),dtype=torch.bool)
                g = similarity_matrix[pos_mask].view(hx.size(0),-1)
                g0 = similarity_matrix[~pos_mask].view(hx.size(0),-1)
                g0_logsumexp = torch.logsumexp(g0,1).view(-1,1)
                output = u + torch.exp(-u+g0_logsumexp-g)/(hx.size(0)-1) - 1

            else:      
                g, u = torch.chunk(self.critic(x,y),2,dim=1)
                if K is not None:

                    for k in range(K-1):

                        if k==0:
                            y0 = y0
                            g0,_ = torch.chunk(self.critic(x,y0),2,dim=1)
                        else:
                            y0 = y[torch.randperm(y.size()[0])]
                            g00,_ = torch.chunk(self.critic(x,y0),2,dim=1)
                            g0 = torch.cat((g0,g00),1)

                    g0_logsumexp = torch.logsumexp(g0,1).view(-1,1)
                    output = u + torch.exp(-u+g0_logsumexp-g)/(K-1) - 1
                else:    

                    g0, _ = torch.chunk(self.critic(x,y0),2,dim=1)
                    output = u + torch.exp(-u+g0-g) - 1
        return output

class TUBABilinearCritic(nn.Module):
    
    '''
    encoder_x : dx -> feature_dim
    encoder_y : dy -> feature_dim
    u_func : 2*feature_dim -> 1
    '''
    
    def __init__(self,
                 encoder_x: nn.Module,
                 encoder_y: nn.Module,
                 u_func: nn.Module,
                 tau: Optional[float] = 1.):
        
        super(TUBABilinearCritic,self).__init__()
        self.encoder_x = encoder_x
        self.encoder_y = encoder_y
        self.u_func = u_func
        self.log_tau = torch.nn.Parameter(torch.log(torch.Tensor([tau])))
        
    
    def forward(self, x, y, tau=None):
        if tau is None:
            tau = torch.exp(self.log_tau)
        tau = torch.sqrt(tau)
        hx = self.norm(self.encoder_x(x))
        hy = self.norm(self.encoder_y(y))
        u = self.u_func(hx)
        
        return hx/tau, hy/tau, u  
    
    def norm(self,z):
        return torch.nn.functional.normalize(z,dim=1)
class Wrapper(nn.Module):
    def __init__(self, func):
        super(Wrapper,self).__init__()
        self.func = func
#         self.dx = dx
#         self.dy = dy
        
    def forward(self, x, y):
        xy = torch.cat([x,y],dim=1)
        
        return self.func(xy)

class WrapperNCE(nn.Module):
    
    def __init__(self, NCE_model):
        
        super(WrapperNCE,self).__init__()
        self.NCE_model = NCE_model
        
    def forward(self, x, y):
        return -self.NCE_model(x, y)
    
    def MI(self, x, y):
        return self.forward(x,y)   
    
task_id = int(sys.argv[1])
method_name = 'TUBA'
lam_list = [2**x for x in np.linspace(-10,6,20)]
lam = lam_list[task_id]

dataset_orig = load_preproc_data_adult()

privileged_groups = [{'sex': 1}]
unprivileged_groups = [{'sex': 0}]
group_name = 'sex'
dataset_orig_train, dataset_orig_test = dataset_orig.split([0.7], shuffle = True)

# Metric for the original dataset
metric_orig_train = BinaryLabelDatasetMetric(dataset_orig_train, 
                                             unprivileged_groups=unprivileged_groups,
                                             privileged_groups=privileged_groups)

metric_orig_test = BinaryLabelDatasetMetric(dataset_orig_test, 
                                             unprivileged_groups=unprivileged_groups,
                                             privileged_groups=privileged_groups)

min_max_scaler = MaxAbsScaler()
dataset_orig_train.features = min_max_scaler.fit_transform(dataset_orig_train.features)
dataset_orig_test.features = min_max_scaler.transform(dataset_orig_test.features)
metric_scaled_train = BinaryLabelDatasetMetric(dataset_orig_train, 
                             unprivileged_groups=unprivileged_groups,
                             privileged_groups=privileged_groups)
metric_scaled_test = BinaryLabelDatasetMetric(dataset_orig_test, 
                             unprivileged_groups=unprivileged_groups,
                             privileged_groups=privileged_groups)

group_idx = np.where([group_name == name for name in dataset_orig_train.feature_names])[0]
x_train = dataset_orig_train.features
y_train = dataset_orig_train.labels
s_train = dataset_orig_train.features[:,group_idx]

x_test = dataset_orig_test.features
y_test = dataset_orig_test.labels
s_test = dataset_orig_test.features[:,group_idx]

args = {}
args['lr'] = 1e-4
args['latent_dim'] = 100
args['num_epochs'] = 30
args["input_dim"] = x_train.shape[1]
args["output_dim"] = 10
args['hidden_dim'] = 10
args['s_dim'] = s_train.shape[1]
args["nclass_y"] = 2
args['lam']=lam
args["burnin"]=5



prior = PriorGaussian(args["latent_dim"])
predictor = MLP(args['output_dim'], args['nclass_y'])
criterion = torch.nn.CrossEntropyLoss()
encoder = EncoderMLPGaussian(args['input_dim'],args['output_dim'])

# enc_z = MLP(args["output_dim"], args['hidden_dim'])
# enc_s = MLP(args['s_dim'], 1)
# MI_estimator_zs = SpectralRenyi(enc_z,enc_s)
# MI_estimator_zs.init_params(encoder(torch.Tensor(x_train[:500]))[0],torch.Tensor(s_train[:500]))

feature_dim = 512
encoder_x = MLP(args['output_dim'], output_dim=feature_dim)
encoder_y = MLP(args['s_dim'], output_dim=feature_dim)
u_func = MLP(feature_dim,hidden_dim=[128])
critic = TUBABilinearCritic(encoder_x, encoder_y,u_func)
mi_model = BilinearTUBANCE(critic)
MI_estimator_zs = WrapperNCE(mi_model)
SFRLC = SupervisedVariationalFairRepresentationLearningCriterion()
SFRLC.fit(x_train, s_train , y_train, encoder, MI_estimator_zs, predictor,
          criterion, prior=prior, beta = 0.01, args = args, renyi=True)

z_train = encoder(torch.Tensor(x_train))[0]
z_test = encoder(torch.Tensor(x_test))[0]

softmax = torch.nn.Softmax(dim=1)

y_score_z_train = predictor(z_train).detach().numpy()
y_score_z_test = predictor(z_test).detach().numpy()

yhat_z_train = np.argmax(y_score_z_train,axis=1)
yhat_z_test = np.argmax(y_score_z_test,axis=1)

y_score_z_train = softmax(predictor(z_train))[:,1].detach().numpy()
y_score_z_test = softmax(predictor(z_test))[:,1].detach().numpy()

dataset_debiasing_train = copy.deepcopy(dataset_orig_train)
dataset_debiasing_train.labels = yhat_z_train
dataset_debiasing_train.scores = y_score_z_train
dataset_debiasing_test = copy.deepcopy(dataset_orig_test)
dataset_debiasing_test.labels = yhat_z_test
dataset_debiasing_test.scores = y_score_z_test

# Metrics for the dataset from model with debiasing
display(Markdown("#### Model - with debiasing - dataset metrics"))
metric_dataset_debiasing_train = BinaryLabelDatasetMetric(dataset_debiasing_train, 
                                             unprivileged_groups=unprivileged_groups,
                                             privileged_groups=privileged_groups)

print("Train set: Difference in mean outcomes between unprivileged and privileged groups = %f" % metric_dataset_debiasing_train.mean_difference())

metric_dataset_debiasing_test = BinaryLabelDatasetMetric(dataset_debiasing_test, 
                                             unprivileged_groups=unprivileged_groups,
                                             privileged_groups=privileged_groups)

print("Test set: Difference in mean outcomes between unprivileged and privileged groups = %f" % metric_dataset_debiasing_test.mean_difference())

classified_metric_debiasing_train = ClassificationMetric(dataset_orig_train, 
                                                 dataset_debiasing_train,
                                                 unprivileged_groups=unprivileged_groups,
                                                 privileged_groups=privileged_groups)

display(Markdown("#### Model - with debiasing - classification metrics"))
classified_metric_debiasing_test = ClassificationMetric(dataset_orig_test, 
                                                 dataset_debiasing_test,
                                                 unprivileged_groups=unprivileged_groups,
                                                 privileged_groups=privileged_groups)
print("Test set: Classification accuracy = %f" % classified_metric_debiasing_test.accuracy())
TPR = classified_metric_debiasing_test.true_positive_rate()
TNR = classified_metric_debiasing_test.true_negative_rate()
bal_acc_debiasing_test = 0.5*(TPR+TNR)
print("Test set: Balanced classification accuracy = %f" % bal_acc_debiasing_test)
print("Test set: Disparate impact = %f" % classified_metric_debiasing_test.disparate_impact())
print("Test set: Equal opportunity difference = %f" % classified_metric_debiasing_test.equal_opportunity_difference())
print("Test set: Average odds difference = %f" % classified_metric_debiasing_test.average_odds_difference())
print("Test set: Theil_index = %f" % classified_metric_debiasing_test.theil_index())


# In[ ]:


result = dict()
result['BinaryMetrics_train'] = metric_dataset_debiasing_train
result['BinaryMetrics_test'] = metric_dataset_debiasing_test
result['ClassificationMetrics_train'] = classified_metric_debiasing_train
result['ClassificationMetrics_test'] = classified_metric_debiasing_test
result['lam'] = lam

np.save('%s_%d.npy'%(method_name,task_id),result)





import numpy as np
from linear_fairness import *
import matplotlib.pyplot as plt
from IPython.display import Markdown, display

class VIB(nn.Module):
    def __init__(self,
                 encoder: nn.Module, #(z|x)
                 decoder: nn.Module, #p(y|z)
                 #criterion: nn.Module,
                 beta: Optional[float] = 1,
                 prior: Optional[nn.Module] = None, #p(z)
                 args: Optional[Dict] = None,
                 cuda: Optional[int] = None) -> None:
        '''
        VIB : variational information bottle neck
        Returns the ELBO of model
        MCMC only
        
        Input:
            encoder       nn.Module     enc(x=None), returns z, log q(z|x)
            decoder       nn.Module     dec(x,z,y=None), returns log p(x|z) or log p(y|x,z)
            prior         nn.Module     prior(z), returns log p(z), default standard Gaussian
            
        Output:
            elbo          float         standard elbo model(x,y=None) (-elbo)
        '''
        
        super(VIB,self).__init__()
        
        self.encoder = encoder
        self.decoder = decoder
        self.beta = beta
        #self.criterion = criterion
        self.prior = prior
        
    def forward(self,
               x: torch.Tensor,
               y: torch.Tensor):
        z, log_q_z_x = self.encoder(x)
        log_p_y_z = self.decoder(y,z)
        
        log_p_z = self.prior(z)
        
        elbo = log_p_y_z + self.beta*(log_p_z - log_q_z_x)
        
        return elbo.mean()
    
    def forwardz(self,
               z: torch.Tensor,
               log_q_z_x: torch.Tensor,
               y: torch.Tensor):
        # z, log_q_z_x = self.encoder(x)
        log_p_y_z = self.decoder(y,z)
        
        log_p_z = self.prior(z)
        
        elbo = log_p_y_z + self.beta*(log_p_z - log_q_z_x)
        
        return elbo.mean()

class DecoderPC(nn.Module):
    
    def __init__(self, predictor, criterion):
        
        super(DecoderPC, self).__init__()
        
        self.predictor = predictor
        self.criterion = criterion
        
    def forward(self, y, z):
        
        yhat = self.predictor(z)
        
        loglik = -self.criterion(yhat,y)
        
        return loglik
    
class EncoderMLPGaussian(nn.Module):
    
    def __init__(self, input_dim, latent_dim, hidden_dim=[512,512]):
        
        super(EncoderMLPGaussian, self).__init__()
        
        self.mlp = MLP(input_dim, 2*latent_dim, hidden_dim)
        self.latent_dim = latent_dim
        self.input_dim = input_dim
        
    def forward(self, x):
        
        # x = x.view(-1,self.input_dim)
        latent_code = self.mlp(x)
        
        mean = latent_code[:,:self.latent_dim]
        std = torch.sqrt(torch.exp(latent_code[:,self.latent_dim:]))
        
        z = mean + std*torch.randn_like(mean)
        
        
        log_q_z_x = (-.5*((z-mean)/std)**2-torch.log(std)).sum(1)
        
        
        return z, log_q_z_x

class PriorGaussian(nn.Module):
    
    def __init__(self, latent_dim):
        
        super(PriorGaussian, self).__init__()
        
        # self.norm = torch.distributions.Normal(torch.Tensor([0]),torch.Tensor([1]))
        
    def forward(self, z):
        
        # log_p_z = self.norm.log_prob(z).sum(1)
        log_p_z = (-.5*(z)**2).sum(1)
        
        return log_p_z
    
class SupervisedVariationalFairRepresentationLearningCriterion(object):
    def __init__(self): 
        pass
        
    def fit(self, X, S, Y, 
            encoder, MI_estimator_zs, 
            predictor, criterion,
            prior=None,beta=1,
            X_val=None, S_val=None, Y_val=None,
            args=None, cuda=None, renyi=False):
        liveloss = PlotLosses()
        num_epochs = 10
        batch_size = 128
        lr = 1e-4
        lam = 1
        burnin = 10
        if args is not None:
            if args.get('num_epochs'): num_epochs = args['num_epochs']
            if args.get('batch_size'): batch_size = args['batch_size']
            if args.get('lr'): lr = args['lr']
            if args.get('lam'): lam = args['lam']
            if 'burnin' in args: burnin = args['burnin']
                
        opt_enc = torch.optim.Adam(params=[*encoder.parameters(),*predictor.parameters()],lr=lr)
        opt_mi = torch.optim.Adam(params= MI_estimator_zs.parameters(),lr=lr)
        
        X = torch.Tensor(X)
        S = torch.Tensor(S)
        Y = torch.Tensor(Y)
        train_data = list(zip(X,S,Y))
        train_loader = torch.utils.data.DataLoader(
            train_data, batch_size=batch_size, shuffle=True, num_workers=1, drop_last=True)
        
        if X_val is not None:
            
            
            X_val = torch.Tensor(X_val)
            S_val = torch.Tensor(S_val)
            Y_val = torch.Tensor(Y_val)
            val_data = list(zip(X_val,S_val,Y_val))
            val_loader = torch.utils.data.DataLoader(
                val_data, batch_size=batch_size, shuffle=True, 
                num_workers=1, drop_last=True)
        else:
            val_loader = None
            
        decoder = DecoderPC(predictor, criterion)
        vib = VIB(encoder,decoder,prior=prior,beta=beta)
        best_loss = np.inf
        best_model_wts = None
        best_epoch = None
        model = ModelWrapper(encoder, MI_estimator_zs, predictor)
        for epoch in range(num_epochs):

            print('Epoch {}/{}'.format(epoch+1, num_epochs))
            print('-' * 10)
        
            mi_losses = []
            enc_losses = []
            zy_losses = []
            zs_losses = []
            val_enc_losses = []
            val_zy_losses = []
            val_zs_losses = []
            
            for i,(x,s,y) in enumerate(train_loader):
                
                # Step-0 Encode X
            
                z,log_q_z_x = encoder(x)
                
                # max I(z,y)
                # min I(z,s)
                
                
                # Step-1: Update MI model
                
                opt_mi.zero_grad()
                        
                ###### Modified to train logit for MI #####
                if renyi:
                    loss_mi = MI_estimator_zs(z,s)
                else:
                    zy_real = torch.cat([z,y],dim=1)
                    zs_real = torch.cat([z,s],dim=1)
                    # x0 = x[torch.randperm(x.size()[0])]
                    s0 = s[torch.randperm(s.size()[0])]
                    z0 = z[torch.randperm(z.size()[0])]
                    zs_fake = torch.cat([z0,s0],dim=1)
                    # zx_fake = torch.cat([z0,x0],dim=1)
                    loss_mi = MI_estimator_zs(zs_real,zs_fake) # p(z,s)/(p(z)*p(s))   
                
                # RenyiMI(z,s)  ShannonMI([z,s],[z[rnd],s[rnd]])
                mi_losses.append(loss_mi.item())
                #############################################

                target_mi = -loss_mi
                target_mi.backward(retain_graph=True)
                opt_mi.step()
                
                
                if epoch < burnin: continue
                # Step-2: Minimize Enc wrt estimated MI
                opt_enc.zero_grad()
                I_zy = vib.forwardz(z,log_q_z_x,y.view(-1).long())
#                 yhat = predictor(z)
#                 # print(yhat.shape)
#                 I_zy = -criterion(yhat,y.view(-1).long()) 
                if renyi:
                    I_zs = MI_estimator_zs.MI(z,s)
                else:
                    I_zs = MI_estimator_zs.MI(zs_real)
                # I_zx = MI_estimator_zx.MI(zx_real)
                loss_enc = I_zs - lam*I_zy
                target_enc = loss_enc
                target_enc.backward()
                opt_enc.step()
                enc_losses.append(loss_enc.item())
                
                zy_losses.append(I_zy.item())
                zs_losses.append(I_zs.item())
                
            if val_loader is not None:
                Z_val,log_q_z_x_val = encoder(X_val)
                zs_real = torch.cat([Z_val,S_val],dim=1)
                # yhat = predictor(Z_val)
                # I_zy = -criterion(yhat,Y_val.view(-1).long()).item()
                I_zy = vib.forwardz(Z_val,log_q_z_x_val,Y_val.view(-1).long()).item()
                I_zs = MI_estimator_zs.MI(zs_real).item()
                I_zs = max(0,I_zs)
                
                loss_enc = I_zs - lam*I_zy
                # print(yhat.shape)
                val_enc_losses.append(loss_enc)
                
                val_zy_losses.append(I_zy)
                val_zs_losses.append(I_zs)
                
                
            val_loss = None
            avg_mi_loss = np.mean(mi_losses)
            if len(enc_losses): 
                avg_enc_loss = np.mean(enc_losses)
                avg_zy_loss = np.mean(zy_losses)
                avg_zs_loss = np.mean(zs_losses)
                
                if X_val is not None:
            
                    avg_val_enc_loss = np.mean(val_enc_losses)
                    avg_val_zy_loss = np.mean(val_zy_losses)
                    avg_val_zs_loss = np.mean(val_zs_losses)
                    
                    val_loss = avg_val_enc_loss
            else:
                avg_enc_loss = 0
                avg_zy_loss = 0
                avg_zs_loss = 0
                
                if X_val is not None:
            
                    avg_val_enc_loss = 0
                    avg_val_zy_loss = 0
                    avg_val_zs_loss = 0
                    
            loss_dict = dict()
            loss_dict.update({'mi_loss': avg_mi_loss})
            loss_dict.update({'enc_loss': avg_enc_loss})
            loss_dict.update({'I_zy': avg_zy_loss})
            loss_dict.update({'I_zs': avg_zs_loss})
            
            if X_val is not None:
                
                loss_dict.update({'val_enc_loss': avg_val_enc_loss})
                loss_dict.update({'val_I_zy': avg_val_zy_loss})
                loss_dict.update({'val_I_zs': avg_val_zs_loss})

            liveloss.update(loss_dict)

            liveloss.draw()
            
            
            if val_loss is not None and val_loss < best_loss:
                # print('Updated')
                best_epoch = epoch+1
                best_loss = val_loss
                best_model_wts = copy.deepcopy(model.state_dict())
#                 torch.save(model.state_dict(), model_path)
#                 self.save()
            if val_loss is not None and (epoch+1-best_epoch)>30: break
    

        if val_loss is not None: model.load_state_dict(best_model_wts)
        
class LinearEncoder(nn.Module):
    def __init__(self,input_dim,output_dim):
        super(LinearEncoder, self).__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.B = torch.nn.parameter.Parameter(torch.Tensor(np.random.randn(input_dim,output_dim)))
        self.normalize()  # Optimizing on the Stiefel-manifold
        
    def forward(self, x):
        
        self.normalize()
        return torch.matmul(x,self.B)
    
    def normalize(self):
        self.B.data = self.gram_schmidt(self.B.data)
    
    def gram_schmidt(self,vv):
        def projection(u, v):
            return (v * u).sum() / (u * u).sum() * u

        nk = vv.size(1)
        uu = torch.zeros_like(vv, device=vv.device)
        uu[:, 0] = vv[:, 0].clone()
        for k in range(1, nk):
            vk = vv[:,k].clone()
            uk = 0
            for j in range(0, k):
                uj = uu[:, j].clone()
                uk = uk + projection(uj, vk)
            uu[:, k] = vk - uk
        for k in range(nk):
            uk = uu[:, k].clone()
            uu[:, k] = uk / uk.norm()
        return uu
            
class UnsupervisedFairRepresentationLearning(object):
    def __init__(self): 
        pass
        
    def fit(self, X, Y, encoder, MI_estimator_zx, MI_estimator_zy,args = None,cuda=None):
        liveloss = PlotLosses()
        batch_size = 128
        lr = 1e-4
        lam = 1
        if args is not None:
            if args.get('num_epochs'): num_epochs = args['num_epochs']
            if args.get('batch_size'): batch_size = args['batch_size']
            if args.get('lr'): lr = args['lr']
            if args.get('lam'): lam = args['lam']
                
        opt_enc = torch.optim.Adam(params=encoder.parameters(),lr=lr)
        opt_mi = torch.optim.Adam(params=[*MI_estimator_zx.parameters(),*MI_estimator_zy.parameters()],lr=lr)
        
        X = torch.Tensor(X)
        Y = torch.Tensor(Y)
        train_data = list(zip(X,Y))
        train_loader = torch.utils.data.DataLoader(
            train_data, batch_size=batch_size, shuffle=True, num_workers=1, drop_last=True)
        for epoch in range(num_epochs):

            print('Epoch {}/{}'.format(epoch+1, num_epochs))
            print('-' * 10)
        
            mi_losses = []
            enc_losses = []
            zy_losses = []
            zx_losses = []
            
            for i,(x,y) in enumerate(train_loader):
                
                # Step-0 Encode X
            
                z = encoder(x)
                
                
                # Step-1: Update MI model
                
                opt_mi.zero_grad()
                        
                ###### Modified to train logit for MI #####
                zy_real = torch.cat([z,y],dim=1)
                zx_real = torch.cat([z,x],dim=1)
                x0 = x[torch.randperm(x.size()[0])]
                y0 = y[torch.randperm(y.size()[0])]
                z0 = z[torch.randperm(z.size()[0])]
                zx_fake = torch.cat([z0,x0],dim=1)
                zy_fake = torch.cat([z0,y0],dim=1)
                loss_mi = MI_estimator_zx(zx_real,zx_fake)+MI_estimator_zy(zy_real,zy_fake)
                mi_losses.append(loss_mi.item())
                #############################################

                target_mi = -loss_mi
                target_mi.backward(retain_graph=True)
                opt_mi.step()
                
                
                if epoch < 10: continue
                # Step-2: Minimize Enc wrt estimated MI
                opt_enc.zero_grad()
                I_zy = MI_estimator_zy.MI(zy_real)
                I_zx = MI_estimator_zx.MI(zx_real)
                loss_enc = I_zy - lam*I_zx
                target_enc = loss_enc
                target_enc.backward()
                opt_enc.step()
                enc_losses.append(loss_enc.item())
                
                zy_losses.append(I_zy.item())
                zx_losses.append(I_zx.item())
                
            avg_mi_loss = np.mean(mi_losses)
            if len(enc_losses): 
                avg_enc_loss = np.mean(enc_losses)
                avg_zy_loss = np.mean(zy_losses)
                avg_zx_loss = np.mean(zx_losses)
            else:
                avg_enc_loss = 0
                avg_zy_loss = 0
                avg_zx_loss = 0
            loss_dict = dict()
            loss_dict.update({'mi_loss': avg_mi_loss})
            loss_dict.update({'enc_loss': avg_enc_loss})
            loss_dict.update({'I_zy': avg_zy_loss})
            loss_dict.update({'I_zx': avg_zx_loss})

            liveloss.update(loss_dict)

            liveloss.draw()

class SupervisedFairRepresentationLearningCriterion(object):
    def __init__(self): 
        pass
        
    def fit(self, X, S, Y, 
            encoder, MI_estimator_zs, 
            predictor, criterion,
            X_val=None,S_val=None,Y_val=None,
            args = None,cuda=None):
        liveloss = PlotLosses()
        num_epochs = 10
        batch_size = 128
        lr = 1e-4
        lam = 1
        burnin = 10
        if args is not None:
            if args.get('num_epochs'): num_epochs = args['num_epochs']
            if args.get('batch_size'): batch_size = args['batch_size']
            if args.get('lr'): lr = args['lr']
            if args.get('lam'): lam = args['lam']
            if 'burnin' in args: burnin = args['burnin']
                
        opt_enc = torch.optim.Adam(params=[*encoder.parameters(),*predictor.parameters()],lr=lr)
        opt_mi = torch.optim.Adam(params= MI_estimator_zs.parameters(),lr=lr)
        
        X = torch.Tensor(X)
        S = torch.Tensor(S)
        Y = torch.Tensor(Y)
        train_data = list(zip(X,S,Y))
        train_loader = torch.utils.data.DataLoader(
            train_data, batch_size=batch_size, shuffle=True, num_workers=1, drop_last=True)
        
        if X_val is not None:
            
            
            X_val = torch.Tensor(X_val)
            S_val = torch.Tensor(S_val)
            Y_val = torch.Tensor(Y_val)
            val_data = list(zip(X_val,S_val,Y_val))
            val_loader = torch.utils.data.DataLoader(
                val_data, batch_size=batch_size, shuffle=True, 
                num_workers=1, drop_last=True)
        else:
            val_loader = None
        
        best_loss = np.inf
        best_model_wts = None
        best_epoch = None
        model = ModelWrapper(encoder, MI_estimator_zs, predictor)
        for epoch in range(num_epochs):

            print('Epoch {}/{}'.format(epoch+1, num_epochs))
            print('-' * 10)
        
            mi_losses = []
            enc_losses = []
            zy_losses = []
            zs_losses = []
            val_enc_losses = []
            val_zy_losses = []
            val_zs_losses = []
            
            for i,(x,s,y) in enumerate(train_loader):
                
                # Step-0 Encode X
            
                z = encoder(x)
                
                # max I(z,y)
                # min I(z,s)
                
                
                # Step-1: Update MI model
                
                opt_mi.zero_grad()
                        
                ###### Modified to train logit for MI #####
                zy_real = torch.cat([z,y],dim=1)
                zs_real = torch.cat([z,s],dim=1)
                # x0 = x[torch.randperm(x.size()[0])]
                s0 = s[torch.randperm(s.size()[0])]
                z0 = z[torch.randperm(z.size()[0])]
                zs_fake = torch.cat([z0,s0],dim=1)
                # zx_fake = torch.cat([z0,x0],dim=1)
                loss_mi = MI_estimator_zs(zs_real,zs_fake)
                mi_losses.append(loss_mi.item())
                #############################################

                target_mi = -loss_mi
                target_mi.backward(retain_graph=True)
                opt_mi.step()
                
                
                if epoch < burnin: continue
                # Step-2: Minimize Enc wrt estimated MI
                opt_enc.zero_grad()
                yhat = predictor(z)
                # print(yhat.shape)
                I_zy = -criterion(yhat,y.view(-1).long()) 
                I_zs = MI_estimator_zs.MI(zs_real)
                # I_zx = MI_estimator_zx.MI(zx_real)
                loss_enc = I_zs - lam*I_zy
                target_enc = loss_enc
                target_enc.backward()
                opt_enc.step()
                enc_losses.append(loss_enc.item())
                
                zy_losses.append(I_zy.item())
                zs_losses.append(I_zs.item())
                
            if val_loader is not None:
                Z_val = encoder(X_val)
                zs_real = torch.cat([Z_val,S_val],dim=1)
                yhat = predictor(Z_val)
                I_zy = -criterion(yhat,Y_val.view(-1).long()).item()
                I_zs = MI_estimator_zs.MI(zs_real).item()
                I_zs = max(0,I_zs)
                
                loss_enc = I_zs - lam*I_zy
                # print(yhat.shape)
                val_enc_losses.append(loss_enc)
                
                val_zy_losses.append(I_zy)
                val_zs_losses.append(I_zs)
                
                
            val_loss = None
            avg_mi_loss = np.mean(mi_losses)
            if len(enc_losses): 
                avg_enc_loss = np.mean(enc_losses)
                avg_zy_loss = np.mean(zy_losses)
                avg_zs_loss = np.mean(zs_losses)
                
                if X_val is not None:
            
                    avg_val_enc_loss = np.mean(val_enc_losses)
                    avg_val_zy_loss = np.mean(val_zy_losses)
                    avg_val_zs_loss = np.mean(val_zs_losses)
                    
                    val_loss = avg_val_enc_loss
            else:
                avg_enc_loss = 0
                avg_zy_loss = 0
                avg_zs_loss = 0
                
                if X_val is not None:
            
                    avg_val_enc_loss = 0
                    avg_val_zy_loss = 0
                    avg_val_zs_loss = 0
                    
            loss_dict = dict()
            loss_dict.update({'mi_loss': avg_mi_loss})
            loss_dict.update({'enc_loss': avg_enc_loss})
            loss_dict.update({'I_zy': avg_zy_loss})
            loss_dict.update({'I_zs': avg_zs_loss})
            
            if X_val is not None:
                
                loss_dict.update({'val_enc_loss': avg_val_enc_loss})
                loss_dict.update({'val_I_zy': avg_val_zy_loss})
                loss_dict.update({'val_I_zs': avg_val_zs_loss})

            liveloss.update(loss_dict)

            liveloss.draw()
            
            
            if val_loss is not None and val_loss < best_loss:
                # print('Updated')
                best_epoch = epoch+1
                best_loss = val_loss
                best_model_wts = copy.deepcopy(model.state_dict())
#                 torch.save(model.state_dict(), model_path)
#                 self.save()
            if val_loss is not None and (epoch+1-best_epoch)>10: break
    
    
        model.load_state_dict(best_model_wts)
        
class SupervisedFairRepresentationLearning(object):
    def __init__(self): 
        pass
        
    def fit(self, X, S, Y, encoder, MI_estimator_zs, MI_estimator_zy, args = None,cuda=None):
        liveloss = PlotLosses()
        num_epochs = 10
        batch_size = 128
        lr = 1e-4
        lam = 1
        burnin = 10
        if args is not None:
            if args.get('num_epochs'): num_epochs = args['num_epochs']
            if args.get('batch_size'): batch_size = args['batch_size']
            if args.get('lr'): lr = args['lr']
            if args.get('lam'): lam = args['lam']
            if args.get('burnin'): burnin = args['burnin']
                
        opt_enc = torch.optim.Adam(params=encoder.parameters(),lr=lr)
        opt_mi = torch.optim.Adam(params=[*MI_estimator_zs.parameters(),*MI_estimator_zy.parameters()],lr=lr)
        
        X = torch.Tensor(X)
        S = torch.Tensor(S)
        Y = torch.Tensor(Y)
        train_data = list(zip(X,S,Y))
        train_loader = torch.utils.data.DataLoader(
            train_data, batch_size=batch_size, shuffle=True, num_workers=1, drop_last=True)
        for epoch in range(num_epochs):

            print('Epoch {}/{}'.format(epoch+1, num_epochs))
            print('-' * 10)
        
            mi_losses = []
            enc_losses = []
            zy_losses = []
            zs_losses = []
            
            for i,(x,s,y) in enumerate(train_loader):
                
                # Step-0 Encode X
            
                z = encoder(x)
                
                # max I(z,y)
                # min I(z,s)
                
                
                # Step-1: Update MI model
                
                opt_mi.zero_grad()
                        
                ###### Modified to train logit for MI #####
                zy_real = torch.cat([z,y],dim=1)
                zs_real = torch.cat([z,s],dim=1)
                # x0 = x[torch.randperm(x.size()[0])]
                y0 = y[torch.randperm(y.size()[0])]
                s0 = s[torch.randperm(s.size()[0])]
                z0 = z[torch.randperm(z.size()[0])]
                zs_fake = torch.cat([z0,s0],dim=1)
                # zx_fake = torch.cat([z0,x0],dim=1)
                zy_fake = torch.cat([z0,y0],dim=1)
                loss_mi = MI_estimator_zs(zs_real,zs_fake)+MI_estimator_zy(zy_real,zy_fake)
                mi_losses.append(loss_mi.item())
                #############################################

                target_mi = -loss_mi
                target_mi.backward(retain_graph=True)
                opt_mi.step()
                
                
                if epoch < burnin: continue
                # Step-2: Minimize Enc wrt estimated MI
                opt_enc.zero_grad()
                I_zy = MI_estimator_zy.MI(zy_real)
                I_zs = MI_estimator_zs.MI(zs_real)
                # I_zx = MI_estimator_zx.MI(zx_real)
                loss_enc = I_zs - lam*I_zy
                target_enc = loss_enc
                target_enc.backward()
                opt_enc.step()
                enc_losses.append(loss_enc.item())
                
                zy_losses.append(I_zy.item())
                zs_losses.append(I_zs.item())
                
            avg_mi_loss = np.mean(mi_losses)
            if len(enc_losses): 
                avg_enc_loss = np.mean(enc_losses)
                avg_zy_loss = np.mean(zy_losses)
                avg_zs_loss = np.mean(zs_losses)
            else:
                avg_enc_loss = 0
                avg_zy_loss = 0
                avg_zs_loss = 0
            
            loss_dict = dict()
            loss_dict.update({'mi_loss': avg_mi_loss})
            loss_dict.update({'enc_loss': avg_enc_loss})
            loss_dict.update({'I_zy': avg_zy_loss})
            loss_dict.update({'I_zs': avg_zs_loss})

            liveloss.update(loss_dict)

            liveloss.draw()
            
class ModelWrapper(nn.Module):
    def __init__(self,encoder,MI_estimator,predictor):
        super(ModelWrapper, self).__init__()
        self.encoder = encoder
        self.MI_estimator = MI_estimator
        self.predictor = predictor

class SupervisedDecoderFairRepresentationLearning(object):
    def __init__(self): 
        pass
        
    def fit(self, X, S, Y, encoder, MI_estimator_zs, MI_estimator_zy, decoder=None, 
            args = None,cuda=None):
        liveloss = PlotLosses()
        num_epochs = 10
        batch_size = 128
        lr = 1e-4
        lam = 1
        burnin = 10
        if args is not None:
            if args.get('num_epochs'): num_epochs = args['num_epochs']
            if args.get('batch_size'): batch_size = args['batch_size']
            if args.get('lr'): lr = args['lr']
            if args.get('lam'): lam = args['lam']
            if 'burnin' in args: burnin = args['burnin']
                
        opt_enc = torch.optim.Adam(params=encoder.parameters(),lr=lr)
        if decoder is None:
            opt_mi = torch.optim.Adam(params=[*MI_estimator_zs.parameters(),*MI_estimator_zy.parameters()],lr=lr)
        else:
            opt_mi = torch.optim.Adam(params=[*MI_estimator_zs.parameters(),*decoder.parameters()],lr=lr)
        
        X = torch.Tensor(X)
        S = torch.Tensor(S)
        Y = torch.Tensor(Y)
        train_data = list(zip(X,S,Y))
        train_loader = torch.utils.data.DataLoader(
            train_data, batch_size=batch_size, shuffle=True, num_workers=1, drop_last=True)
        for epoch in range(num_epochs):

            print('Epoch {}/{}'.format(epoch+1, num_epochs))
            print('-' * 10)
        
            mi_losses = []
            enc_losses = []
            zy_losses = []
            zs_losses = []
            
            for i,(x,s,y) in enumerate(train_loader):
                
                # Step-0 Encode X
            
                z = encoder(x)
                
                # max I(z,y)
                # min I(z,s)
                
                # # if decoder is avaialble, use (dec(z)-y)^2 instead of 
                
                # supervised(x,s,y) => I(z,s) - lam* I(z,y)
                # unsupervised(x,s) => I(z,s) - lam* I(z,x)
                # supervised(x,s,x) => I(z,s) - lam* I(z,x)
                # I(z,y) => (dec(z)-y)^2
                
                
                # Step-1: Update MI model
                
                opt_mi.zero_grad()
                        
                ###### Modified to train logit for MI #####
                zy_real = torch.cat([z,y],dim=1)
                zs_real = torch.cat([z,s],dim=1)
                # x0 = x[torch.randperm(x.size()[0])]
                y0 = y[torch.randperm(y.size()[0])]
                s0 = s[torch.randperm(s.size()[0])]
                z0 = z[torch.randperm(z.size()[0])]
                zs_fake = torch.cat([z0,s0],dim=1)
                # zx_fake = torch.cat([z0,x0],dim=1)
                zy_fake = torch.cat([z0,y0],dim=1)
                # loss_mi = MI_estimator_zs(zs_real,zs_fake)+MI_estimator_zy(zy_real,zy_fake)
                loss_mi = MI_estimator_zs(zs_real,zs_fake)
                if decoder is None:
                    loss_mi += MI_estimator_zy(zy_real,zy_fake)
                else: 
                    # criterion => criterion(decoder(z), y)
                    loss_mi += (-(y-decoder(z))**2).sum(dim=[-1]).mean()  
                mi_losses.append(loss_mi.item())
                #############################################

                target_mi = -loss_mi
                target_mi.backward(retain_graph=True)
                opt_mi.step()
                
                
                if epoch < burnin: continue
                # Step-2: Minimize Enc wrt estimated MI
                opt_enc.zero_grad()
                if decoder is None:
                    I_zy = MI_estimator_zy.MI(zy_real)
                else:
                    I_zy = (-(y-decoder(z))**2).sum(dim=[-1]).mean()  
                I_zs = MI_estimator_zs.MI(zs_real)
                # I_zx = MI_estimator_zx.MI(zx_real)
                loss_enc = I_zs - lam*I_zy
                target_enc = loss_enc
                target_enc.backward()
                opt_enc.step()
                enc_losses.append(loss_enc.item())
                
                zy_losses.append(I_zy.item())
                zs_losses.append(I_zs.item())
                
            avg_mi_loss = np.mean(mi_losses)
            if len(enc_losses): 
                avg_enc_loss = np.mean(enc_losses)
                avg_zy_loss = np.mean(zy_losses)
                avg_zs_loss = np.mean(zs_losses)
            else:
                avg_enc_loss = 0
                avg_zy_loss = 0
                avg_zs_loss = 0
            
            loss_dict = dict()
            loss_dict.update({'mi_loss': avg_mi_loss})
            loss_dict.update({'enc_loss': avg_enc_loss})
            loss_dict.update({'I_zy': avg_zy_loss})
            loss_dict.update({'I_zs': avg_zs_loss})

            liveloss.update(loss_dict)

            liveloss.draw()
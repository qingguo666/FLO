import sys
sys.path.append("../")
from aif360.datasets import BinaryLabelDataset
from aif360.datasets import AdultDataset
from aif360.metrics import BinaryLabelDatasetMetric
from aif360.metrics import ClassificationMetric
from aif360.metrics.utils import compute_boolean_conditioning_vector


# from aif360.algorithms.preprocessing.reweighing import Reweighing
from aif360.algorithms.preprocessing.optim_preproc_helpers.data_preproc_functions            import load_preproc_data_adult

from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler, MaxAbsScaler
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report

from IPython.display import Markdown, display
import matplotlib.pyplot as plt
import numpy as np

#from aif360.examples.common_utils import compute_metrics
import copy
from sklearn.preprocessing import normalize, StandardScaler
import csv
from math import sqrt
import math
from sklearn.metrics import normalized_mutual_info_score
import pandas as pd
from tqdm import tqdm


# In[2]:


def grad_sigmoid(x):
    return np.exp(-x) / ((1.0 + np.exp(-x)) * (1.0 + np.exp(-x)))


def sigmoid(x):  # P(Y = 1 | X, \theta) Input: X\theta
    return 1.0 / (1.0 + np.exp(-x))


def loss1(predictions, labels):
    return (-labels * np.log(predictions) - (1 - labels) * np.log(1 - predictions)).mean()


# In[3]:

lam_list = [0,
            100,
            3000,
            30000,
            60000,
            120000,
            180000,
            300000,
            500000,
            900000,
            1200000,
            3000000,
            5000000,
            9000000,
            30000000,
            40000000,
            ]

task_id = int(sys.argv[1])
lam = lam_list[task_id]


# In[4]:


# lam = 3e5


# In[5]:


method_name = 'fermi'


# In[25]:


class FERMI(object):
    def __init__(self, d):
        self.theta = np.zeros((d, 1))
        self.d = d
        
    def fit(self, X, S, Y, args=None,lam = 3e5):
        d = self.d
        theta = self.theta
        Y_ = Y
        n = X.shape[0]
        num_iterations = 5000
        step_size = 0.0001
        number_of_sensitive_attributes = len(np.unique(S))
        if args is not None:
            if 'num_iterations' in args: num_iterations = args['num_iterations']
            if 'lr' in args: step_size = args['lr']
        for iter_num in tqdm(range(num_iterations)):
            logits = np.dot(X, theta)
            probs = sigmoid(logits)
            grad_probs = grad_sigmoid(logits)

            g1 = np.dot(X.T, (probs - Y_.reshape(-1,1)))

            P_Y1 = sum(probs) / n
            P_Y0 = 1 - P_Y1

            D = grad_probs.flatten()

            grad_Y1 = (D.reshape(-1,1)*X).sum(axis=0).reshape(d, 1)
            grad_Y1 /= n
            grad_Y0 = - grad_Y1

            regularizer_grad = np.zeros(theta.shape)

            for j in range(number_of_sensitive_attributes):
                indicator_function = (S == j) * 1
                
                number_of_s = sum(indicator_function)
                P_S = number_of_s / n
                P_Y1S = np.dot(indicator_function.T, probs) / number_of_s
                P_Y0S = 1 - P_Y1S

                q_1j = P_Y1S * sqrt(P_S) / sqrt(P_Y1)
                q_0j = P_Y0S * sqrt(P_S) / sqrt(P_Y0)

                # Computing the gradient with respect to theta

                conditional_grad_probs = np.multiply(indicator_function.reshape(-1,1), grad_probs)

                D = conditional_grad_probs.flatten()
                grad_Y1S = (D.reshape(-1,1)*X).sum(axis=0).reshape(d, 1)
                grad_Y1S /= number_of_s
                grad_Y0S = - grad_Y1S

                # Gradient of q_ij with respect to theta:
                grad_q1j = sqrt(P_S) / P_Y1 * (sqrt(P_Y1) * grad_Y1S - P_Y1S / (2 * sqrt(P_Y1)) * grad_Y1)
                grad_q0j = sqrt(P_S) / P_Y0 * (sqrt(P_Y0) * grad_Y0S - P_Y0S / (2 * sqrt(P_Y0)) * grad_Y0)

                regularizer_grad += 2 * q_1j * grad_q1j + 2 * q_0j * grad_q0j

            theta -= step_size * (g1 + lam * regularizer_grad)

#         # ------------------------------------------------------------------------
#         # Training
#         testOut = np.dot(X, theta)
#         testProbs = sigmoid(testOut)

#         preds = testProbs >= 0.5
#         acc = (preds == Y_).mean()
#         print(acc)
    def predict_proba(self, X):
        theta = self.theta
        testOut = np.dot(X, theta)
        testProbs = sigmoid(testOut)
        return testProbs
    
    def predict(self, X):
        testProbs = self.predict_proba(X)
        preds = testProbs >= 0.5
        


# #### Load dataset and set options

# In[7]:


# Get the dataset and split into train and test
dataset_orig = load_preproc_data_adult()

privileged_groups = [{'sex': 1}]
unprivileged_groups = [{'sex': 0}]
group_name = 'sex'
dataset_orig_train, dataset_orig_test = dataset_orig.split([0.7], shuffle = True)
#dataset_orig_train, dataset_orig_valid = dataset_orig_train.split([0.8],shuffle = True)


# In[8]:


# print out some labels, names, etc.
display(Markdown("#### Training Dataset shape"))
print(dataset_orig_train.features.shape)
display(Markdown("#### Favorable and unfavorable labels"))
print(dataset_orig_train.favorable_label, dataset_orig_train.unfavorable_label)
display(Markdown("#### Protected attribute names"))
print(dataset_orig_train.protected_attribute_names)
display(Markdown("#### Privileged and unprivileged protected attribute values"))
print(dataset_orig_train.privileged_protected_attributes, 
      dataset_orig_train.unprivileged_protected_attributes)
display(Markdown("#### Dataset feature names"))
print(dataset_orig_train.feature_names)


# #### Metric for original training data

# In[9]:


# Metric for the original dataset
metric_orig_train = BinaryLabelDatasetMetric(dataset_orig_train, 
                                             unprivileged_groups=unprivileged_groups,
                                             privileged_groups=privileged_groups)
display(Markdown("#### Original training dataset"))
print("Train set: Difference in mean outcomes between unprivileged and privileged groups = %f" % metric_orig_train.mean_difference())
metric_orig_test = BinaryLabelDatasetMetric(dataset_orig_test, 
                                             unprivileged_groups=unprivileged_groups,
                                             privileged_groups=privileged_groups)
print("Test set: Difference in mean outcomes between unprivileged and privileged groups = %f" % metric_orig_test.mean_difference())


# In[10]:


min_max_scaler = MaxAbsScaler()
dataset_orig_train.features = min_max_scaler.fit_transform(dataset_orig_train.features)
dataset_orig_test.features = min_max_scaler.transform(dataset_orig_test.features)
metric_scaled_train = BinaryLabelDatasetMetric(dataset_orig_train, 
                             unprivileged_groups=unprivileged_groups,
                             privileged_groups=privileged_groups)
display(Markdown("#### Scaled dataset - Verify that the scaling does not affect the group label statistics"))
print("Train set: Difference in mean outcomes between unprivileged and privileged groups = %f" % metric_scaled_train.mean_difference())
metric_scaled_test = BinaryLabelDatasetMetric(dataset_orig_test, 
                             unprivileged_groups=unprivileged_groups,
                             privileged_groups=privileged_groups)
print("Test set: Difference in mean outcomes between unprivileged and privileged groups = %f" % metric_scaled_test.mean_difference())


# In[11]:


group_idx = np.where([group_name == name for name in dataset_orig_train.feature_names])[0]


# In[15]:


x_train = dataset_orig_train.features
y_train = dataset_orig_train.labels
s_train = dataset_orig_train.features[:,group_idx]

x_test = dataset_orig_test.features
y_test = dataset_orig_test.labels
s_test = dataset_orig_test.features[:,group_idx]

# x_valid = dataset_orig_val.features
# y_valid = dataset_orig_val.labels
# s_valid = dataset_orig_val.features[:,group_idx]


# In[12]:


args = {}
args['lr'] = 1e-4
args['latent_dim'] = 100
args['num_epochs'] = 30
args["input_dim"] = x_train.shape[1]
args["output_dim"] = 10
args['hidden_dim'] = 10
args['s_dim'] = s_train.shape[1]
args["nclass_y"] = 2
args['lam']=lam
args["burnin"]=5


# In[26]:


fermi = FERMI(x_train.shape[1])
s_train = s_train.reshape(-1)
y_train = y_train.reshape(-1)
fermi.fit(x_train, s_train, y_train,args=args, lam=lam)


# In[27]:



y_score_z_train = fermi.predict_proba(x_train)
y_score_z_test = fermi.predict_proba(x_test)

yhat_z_train = y_score_z_train>=0.5
yhat_z_test = y_score_z_test>=0.5



# In[28]:


dataset_debiasing_train = copy.deepcopy(dataset_orig_train)
dataset_debiasing_train.labels = yhat_z_train
dataset_debiasing_train.scores = y_score_z_train
dataset_debiasing_test = copy.deepcopy(dataset_orig_test)
dataset_debiasing_test.labels = yhat_z_test
dataset_debiasing_test.scores = y_score_z_test


# In[29]:


# Metrics for the dataset from model with debiasing
display(Markdown("#### Model - with debiasing - dataset metrics"))
metric_dataset_debiasing_train = BinaryLabelDatasetMetric(dataset_debiasing_train, 
                                             unprivileged_groups=unprivileged_groups,
                                             privileged_groups=privileged_groups)

print("Train set: Difference in mean outcomes between unprivileged and privileged groups = %f" % metric_dataset_debiasing_train.mean_difference())

metric_dataset_debiasing_test = BinaryLabelDatasetMetric(dataset_debiasing_test, 
                                             unprivileged_groups=unprivileged_groups,
                                             privileged_groups=privileged_groups)

print("Test set: Difference in mean outcomes between unprivileged and privileged groups = %f" % metric_dataset_debiasing_test.mean_difference())

classified_metric_debiasing_train = ClassificationMetric(dataset_orig_train, 
                                                 dataset_debiasing_train,
                                                 unprivileged_groups=unprivileged_groups,
                                                 privileged_groups=privileged_groups)

display(Markdown("#### Model - with debiasing - classification metrics"))
classified_metric_debiasing_test = ClassificationMetric(dataset_orig_test, 
                                                 dataset_debiasing_test,
                                                 unprivileged_groups=unprivileged_groups,
                                                 privileged_groups=privileged_groups)
print("Test set: Classification accuracy = %f" % classified_metric_debiasing_test.accuracy())
TPR = classified_metric_debiasing_test.true_positive_rate()
TNR = classified_metric_debiasing_test.true_negative_rate()
bal_acc_debiasing_test = 0.5*(TPR+TNR)
print("Test set: Balanced classification accuracy = %f" % bal_acc_debiasing_test)
print("Test set: Disparate impact = %f" % classified_metric_debiasing_test.disparate_impact())
print("Test set: Equal opportunity difference = %f" % classified_metric_debiasing_test.equal_opportunity_difference())
print("Test set: Average odds difference = %f" % classified_metric_debiasing_test.average_odds_difference())
print("Test set: Theil_index = %f" % classified_metric_debiasing_test.theil_index())


# In[ ]:


result = dict()
result['BinaryMetrics_train'] = metric_dataset_debiasing_train
result['BinaryMetrics_test'] = metric_dataset_debiasing_test
result['ClassificationMetrics_train'] = classified_metric_debiasing_train
result['ClassificationMetrics_test'] = classified_metric_debiasing_test
result['lam'] = lam

np.save('%s_%d.npy'%(method_name,task_id),result)


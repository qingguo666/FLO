import os
import argparse
import logging
from typing import Dict, List, Tuple, Optional, Set
from torch import nn  # type: ignor
import numpy as np  # type: ignore
import pandas as pd  # type: ignore
from scipy import sparse as sp  # type: ignore
import torch  # type: ignore
from torch.utils import data  # type: ignore
from numpy.random import RandomState  # type: ignore
from typing import List, Tuple, Any, Optional
from scipy import sparse as sp  # type: ignore

import matplotlib.pyplot as plt

from torchvision import datasets, transforms
from torch.utils.data import DataLoader, Dataset

from livelossplot import PlotLosses

import time
import copy
import sys


class JSDGAN(nn.Module):
    def __init__(self,
                 critic: nn.Module, 
                 generator: Optional[nn.Module]=None, 
                 f: Optional[nn.Module] = torch.nn.Identity(), 
                 args: Optional[Dict] = None,
                 cuda: Optional[int] = None) -> None:
        '''
        Returns the ELBO of model
        MCMC only
        
        Input:
            critic          nn.Module    D(x) X->R
            generator       nn.Module    Z->X
            
        Output:
            JSD          float         variational objective
        '''
        
        super(JSDGAN,self).__init__()
        
        self.critic = critic
        self.generator = generator
        self.f = f
        
    def forward(self,
               x_real: torch.Tensor, 
               x_fake: Optional[torch.Tensor]=None):
        
        n = x_real.shape[0]
        if x_fake is None:
            x_fake = self.generator(n=n)
        
        D_real = self.critic(x_real)
        D_fake = self.critic(x_fake)
        
        softplus = torch.nn.functional.softplus
        
        # V = -softplus(-D_real).mean()-softplus(D_fake).mean()
        V = (-softplus(-D_real)-softplus(D_fake)).mean()
        
        # Mutual information
        # I = D_real.mean()
        
        return V
    
    def MI(self, x_real: torch.Tensor):
        
        D_real = self.critic(x_real)
        I = self.f(D_real).mean()
        
        return I

class MLP(nn.Module):
    def __init__(self, input_dim, output_dim=1, hidden_dim=[512,512], act_func=nn.ReLU()):
        super(MLP,self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.act_func = act_func
        
        layers = []
        for i in range(len(hidden_dim)):
            if i==0:
                layer = nn.Linear(input_dim, hidden_dim[i])
            else:
                layer = nn.Linear(hidden_dim[i-1], hidden_dim[i])
            nn.init.xavier_uniform_(layer.weight)
            nn.init.zeros_(layer.bias)
            layers.append(layer)
            #layers.append(nn.ReLU(True))
            layers.append(act_func)
        if len(hidden_dim):                #if there is more than one hidden layer
            layer = nn.Linear(hidden_dim[-1], output_dim)
        else:
            layer = nn.Linear(input_dim, output_dim)
        nn.init.xavier_uniform_(layer.weight)
        nn.init.zeros_(layer.bias)
        layers.append(layer)
        
        self._main = nn.Sequential(*layers)
        
    def forward(self, x):
        out = x.view(x.shape[0], self.input_dim)
        out = self._main(out)
        return out
     
        
        
class FairRepresentationLearning(object):
    def __init__(self): 
        pass
        
    def fit(self, X, Y, encoder, MI_estimator, args = None,cuda=None):
        liveloss = PlotLosses()
        num_epochs = 10
        batch_size = 128
        lr = 1e-4
        if args is not None:
            if args.get('num_epochs'): num_epochs = args['num_epochs']
            if args.get('batch_size'): batch_size = args['batch_size']
            if args.get('lr'): lr = args['lr']
                
        opt_enc = torch.optim.Adam(params=encoder.parameters(),lr=lr)
        opt_mi = torch.optim.Adam(params=MI_estimator.parameters(),lr=lr)
        
        X = torch.Tensor(X)
        Y = torch.Tensor(Y)
        train_data = list(zip(X,Y))
        train_loader = torch.utils.data.DataLoader(
            train_data, batch_size=batch_size, shuffle=True, num_workers=1, drop_last=True)
        for epoch in range(num_epochs):

            print('Epoch {}/{}'.format(epoch+1, num_epochs))
            print('-' * 10)
        
            mi_losses = []
            enc_losses = []
            for i,(x,y) in enumerate(train_loader):
                
                # Step-0 Encode X
            
                x = encoder(x)
                
                
                # Step-1: Update MI model
                
                opt_mi.zero_grad()
                        
                ###### Modified to train logit for MI #####
                z_real = torch.cat([x,y],dim=1)
                x0 = x[torch.randperm(x.size()[0])]
                y0 = y[torch.randperm(y.size()[0])]
                z_fake = torch.cat([x0,y0],dim=1)
                loss_mi = MI_estimator(z_real,z_fake)
                mi_losses.append(loss_mi.item())
                #############################################

                target_mi = -loss_mi
                target_mi.backward(retain_graph=True)
                opt_mi.step()
                
                
                if epoch < 10: continue
                # Step-2: Minimize Enc wrt estimated MI
                opt_enc.zero_grad()
                loss_enc  = MI_estimator.MI(z_real)
                target_enc = loss_enc
                target_enc.backward()
                opt_enc.step()
                enc_losses.append(loss_enc.item())
                
            avg_mi_loss = np.mean(mi_losses)
            if len(enc_losses): 
                avg_enc_loss = np.mean(enc_losses)
            else:
                avg_enc_loss = 0
            
            loss_dict = dict()
            loss_dict.update({'mi_loss': avg_mi_loss})
            loss_dict.update({'enc_loss': avg_enc_loss})
    

            liveloss.update(loss_dict)

            liveloss.draw()
                    
        
        
        
        
        
        
                
import os
from utilities import *
import numpy as np
import sys


task_id = int(sys.argv[1])
klist = [2,5,10,20,50]
nk = len(klist)
nr = 20
rholist = np.linspace(0,0.99,nr)
rho = rholist[task_id%nr]
k = klist[task_id//nr]
p = 10
n = 10000
N = n*p
mu = np.array([[0,0]])
sigma = np.array([[[1,rho],[rho,1]]])
GMS = GaussianMixtureSample(mu,sigma)

args = {}
args['lr'] = 1e-4
args['latent_dim'] = 100
args['num_epochs'] = 50
args["input_dim"] = 2*p

alpha = 0.8
critic = Wrapper(MLP(args["input_dim"]))
u_func = MLP(args["input_dim"]//2)
model = Alpha(critic,u_func,alpha)
mitrainer = AlphaTrainer(model)


sampler = ToySampler(rho,p)
train_data = sampler.sample(n)
mitrainer.fit(train_data,K = k, sampler=sampler, args = args)

x = GMS.sample(N)
x = torch.Tensor(x)
x1 = x[(n*0):(n*(0+1)),0].reshape([-1,1])
y1 = x[(n*0):(n*(0+1)),1].reshape([-1,1])
for i in range(p-1):
    i = i + 1
    xi = x[(n*i):(n*(i+1)),0].reshape([-1,1])
    yi = x[(n*i):(n*(i+1)),1].reshape([-1,1])
    x1 = torch.cat((x1,xi),1)
    y1 = torch.cat((y1,yi),1) 
    
y_list = [y1]
for ki in range(k-1):
    y0 = y1[torch.randperm(y1.size()[0])]
    y_list.append(y0)


mi = dict()
mi['pmi'] = model.PMI(x1,y_list)
mi['k'] = k
mi['rho'] = rho
np.save('Ialphami_%d_%d.npy' % (k,task_id%nr), mi)


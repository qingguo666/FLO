import os
from utilities import *
import numpy as np
import sys
class TUBA(nn.Module):
    def __init__(self,
         critic: nn.Module, 
         u_func: nn.Module,
         K: Optional[int] = None,
         args: Optional[Dict] = None,
         cuda: Optional[int] = None) -> None:
        
        super(TUBA,self).__init__()
        self.critic = critic
        self.u_func = u_func
        self.K = K
        
    def forward(self, x, y, y0,K=None):
        
        
        if K is None:
            K = self.K
            
        output = self.PMI(x,y,y0,K)
        
        return output.mean()
    
    def MI(self, x, y, K=10):
        mi = 0
        for k in range(K):
            y0 = y[torch.randperm(y.size()[0])]
            mi += self.forward(x,y,y0)
            
        return -mi/K        
    def PMI(self, x, y, y0,K=None):
        '''
        x:    n x p
        y:    n x d true
        y0:   n x d fake 
        '''
    
        g = self.critic(x, y)
        u  = self.u_func(x)
        if K is not None:
            
            for k in range(K-1):
                
                if k==0:
                    y0 = y0
                    g0 = self.critic(x, y0)
                else:
                    y0 = y[torch.randperm(y.size()[0])]
                    g0 = torch.cat((g0,self.critic(x, y0)),1)
                    
            g0_logsumexp = torch.logsumexp(g0,1).view(-1,1)
            output = -g + u + torch.exp(-u+g0_logsumexp)/(K-1) -1
        else:
            g0 = self.critic(x, y0)
            output = -g + u + torch.exp(-u+g0) - 1
        
        
        return output
    
class TUBATrainer(object):
    
    def __init__(self, model):
        
        self.model = model
        
    def fit(self, train_data, sampler = None, K = None, args=None):
        
        model = self.model
        
        since = time.time()
        liveloss = PlotLosses()

        num_epochs = 10
        batch_size = 128
        lr = 1e-4
        if args is not None:
            if args.get('num_epochs'): num_epochs = args['num_epochs']
            if args.get('batch_size'): batch_size = args['batch_size']
            if args.get('lr'): lr = args['lr']
        
        
        D = model.critic
        U = model.u_func

        #opt_D = torch.optim.Adam(params=D.parameters(),lr=lr)
        opt_D = torch.optim.Adam(params=[*D.parameters(),*U.parameters()],lr=lr)
        
        
        best_acc = -np.infty
        best_loss = np.infty
        best_epoch = 0
        best_model_wts = copy.deepcopy(model.state_dict())
        
        train_loader = torch.utils.data.DataLoader(
            train_data, batch_size=batch_size, shuffle=True, num_workers=1, drop_last=True)
#         val_loader = torch.utils.data.DataLoader(
#             val_data, batch_size=batch_size, shuffle=True, num_workers=1, drop_last=True)
        val_loader = []
        
        data_loaders = {'train': train_loader, 'val': val_loader}
        dataset_sizes = {'train': len(train_loader), 'val': len(val_loader)}
        
        for epoch in range(num_epochs):
            if sampler is not None:
                train_data = sampler.sample(len(train_data))
                train_loader = torch.utils.data.DataLoader(
                            train_data, batch_size=batch_size, 
                            shuffle=True, num_workers=1, drop_last=True)
                
                data_loaders = {'train': train_loader, 'val': val_loader}

            print('Epoch {}/{}'.format(epoch+1, num_epochs))
            print('-' * 10)

            for phase in ['train']:

                if phase == 'train':
                    model.train()
                else:
                    model.eval()

                running_loss = 0.0
                running_acc = torch.Tensor([0])
        #         running_regs = [0.]*len(regs)

                for i,(x,y) in enumerate(data_loaders[phase]):
                    
                    if phase == 'train': 
                        
                
                        opt_D.zero_grad()
                        
                        ###### Modified to train logit for MI ######
                        
                    
                        y0 = y[torch.randperm(y.size()[0])]

                        
                        if K is None:                           
                            fnice = model(x,y,y0)
                        else:
                            fnice = model(x,y,y0,K=K)
                        loss = fnice
                        #############################################
                        
                        target_D = loss
                        target_D.backward()
                        opt_D.step()
                    
                        

                    running_loss += target_D.item() 
            

                    print("\rIteration: {}/{}, Loss: {:.3f}\r".format(i+1, len(data_loaders[phase]), 
                                                        loss.item() ), end="")
                    sys.stdout.flush()

                epoch_loss = running_loss / dataset_sizes[phase]

                avg_loss = epoch_loss
        

            loss_dict = dict()
            loss_dict.update({'log loss': avg_loss})
    
        #     for j,(alph,reg,name,rnd_pair) in enumerate(regs):
        #         loss_dict.update({name: avg_regs[j], 'val_'+name: val_regs[j]})

            liveloss.update(loss_dict)

            liveloss.draw()
            
          
        time_elapsed = time.time() - since
        
        print('Training complete in {:.0f}m {:.0f}s'.format(
            time_elapsed // 60, time_elapsed % 60))
        
#         self.load()
        
        return None

task_id = int(sys.argv[1])
klist = [2,5,10,20,50]
nk = len(klist)
nr = 20
rholist = np.linspace(0,0.99,nr)
rho = rholist[task_id%nr]
k = klist[task_id//nr]
p = 10
n = 10000
N = n*p
mu = np.array([[0,0]])
sigma = np.array([[[1,rho],[rho,1]]])
GMS = GaussianMixtureSample(mu,sigma)



args = {}
args['lr'] = 1e-3
args['latent_dim'] = 100
args['num_epochs'] = 50
args["input_dim"] = 2*p

critic = Wrapper(MLP(args["input_dim"]))
u_func = MLP(args["input_dim"]//2)
model = TUBA(critic, u_func)
mitrainer = TUBATrainer(model)

sampler = ToySampler(rho,p)
train_data = sampler.sample(n)
mitrainer.fit(train_data,sampler=sampler,K=k, args = args)

x = GMS.sample(N)
x = torch.Tensor(x)
x1 = x[(n*0):(n*(0+1)),0].reshape([-1,1])
y1 = x[(n*0):(n*(0+1)),1].reshape([-1,1])
for i in range(p-1):
    i = i + 1
    xi = x[(n*i):(n*(i+1)),0].reshape([-1,1])
    yi = x[(n*i):(n*(i+1)),1].reshape([-1,1])
    x1 = torch.cat((x1,xi),1)
    y1 = torch.cat((y1,yi),1) 
y0 = y1[torch.randperm(y1.size()[0])]
    

mi = dict()
mi['pmi'] = model.PMI(x1,y1,y0,K=k)
mi['rho'] = rho
mi['k'] = k
np.save('tubami_%d_%d.npy' % (k,task_id%nr), mi)

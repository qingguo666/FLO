Code Introduction


2D: This file contains MI lower bound estimation methods: NWJ, TUBA, FLO, InfoNCE, and Ialpha in 2D-Gaussians Toy model.

20D: This file contains MI lower bound estimation methods: NWJ, TUBA, FLO, InfoNCE, and Ialpha in 20D-Gaussians Toy model.

20Dmulti: This file contains MI lower bound estimation methods: NWJ, TUBA, FLO, InfoNCE, and Ialpha in 20D-Gaussians Toy model with the same negative samples K.

BilinearsharedfuncCompare : This file contains the code achieving  the figure: Comparison of computation time of joint MLP critic and bi-linear critic.

Classicmethod: This file contains the code achieving NPEET, knnie, knnie revised and KDE

Fairlearning: This file contains the code that apply FERMI, Adversarial Debiasing, FLO, FDV, NWJ, InfoNCE, TUBA to fair learning.

MNIST: This file contains the MI lower bounds methods used in MNNIST dataset.

MNIST-ImageNet: This file contains the code achieving the methods comparison in MNIST and Tiny ImageNet dataset with ResNet-50.
NetworkComparison: This compares the complexation of neural network affecting the performance.




import os
from utilities import *
import numpy as np
import sys


task_id = int(sys.argv[1])
rholist = np.linspace(0,0.99,20)
rho = rholist[task_id]
mu = np.array([[0,0]])
sigma = np.array([[[1,rho],[rho,1]]])
GMS = GaussianMixtureSample(mu,sigma)

args = {}
args['lr'] = 1e-4
args['latent_dim'] = 100
args['num_epochs'] = 50
args["input_dim"] = 2

critic = Wrapper(MLP(args["input_dim"]))
u_func = Wrapper(MLP(args["input_dim"]))
model = FenchelInfoNCE(critic, u_func)
mitrainer = FenchelInfoNCETrainer(model)

x = GMS.sample(10000)
x = torch.Tensor(x)
train_data = list(zip(x[:,0].reshape([-1,1]),x[:,1].reshape([-1,1])))
mitrainer.fit(train_data,args = args)

y = x[:,1].view(-1,1)
x = x[:,0].view(-1,1)
y0 = y[torch.randperm(y.size()[0])]
    

mi = dict()
mi['pmi'] = model.PMI(x,y,y0)
mi['rho'] = rho
np.save('fpmi_%d.npy' % task_id, mi)

import os
from utilities import *
import numpy as np
import sys


task_id = int(sys.argv[1])
klist = [2,5,10,20,50]
nk = len(klist)
nr = 20
rholist = np.linspace(0,0.99,nr)
rho = rholist[task_id%nr]
k = klist[task_id//nr]
mu = np.array([[0,0]])
sigma = np.array([[[1,rho],[rho,1]]])
GMS = GaussianMixtureSample(mu,sigma)

args = {}
args['lr'] = 1e-4
args['latent_dim'] = 100
args['num_epochs'] = 50
args["input_dim"] = 2

critic = MLP(args["input_dim"])
model = InfoNCE(critic)
mitrainer = InfoNCETrainer(model)

x = GMS.sample(10000)
x = torch.Tensor(x)
train_data = list(zip(x[:,0].reshape([-1,1]),x[:,1].reshape([-1,1])))
mitrainer.fit(train_data,K=k,args = args)

y = x[:,1].view(-1,1)
x = x[:,0].view(-1,1)
y_list = [y]
for ki in range(k-1):
    y0 = y[torch.randperm(y.size()[0])]
    y_list.append(y0)

mi = dict()
mi['pmi'] = model.PMI(x,y_list)
mi['rho'] = rho
mi['k'] = k
np.save('infomi_%d_%d.npy' % (k,task_id%nr), mi)

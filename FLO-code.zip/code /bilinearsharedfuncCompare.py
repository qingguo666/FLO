import os
from utilities import *
import numpy as np
import sys

class BilinearFenchelInfoNCEOne(nn.Module):
    def __init__(self,
         critic: nn.Module, 
         u_func: Optional[nn.Module] = None,
         K: Optional[int] = None,
         args: Optional[Dict] = None,
         cuda: Optional[int] = None) -> None:
        
        super(BilinearFenchelInfoNCEOne,self).__init__()
        self.critic = critic
        self.u_func = u_func
        self.K = K
    def forward(self, x, y, y0,K=None):
        
        '''
        x:    n x p
        y:    n x d true
        y0:   n x d fake 
        '''
        if K is None:
            K = self.K 
#         g = self.critic(x, y)
#         g0 = self.critic(x, y0)
#         u  = self.u_func(x, y)
#         output = u + torch.exp(-u+g0-g) - 1
        output  = self.PMI(x,y,y0,K)
        return output.mean()
    
    def MI(self, x, y, K=10):
        mi = 0
        for k in range(K):
            y0 = y[torch.randperm(y.size()[0])]
            mi += self.forward(x,y,y0)
            
        return -mi/K      
    def PMI(self, x, y, y0=None, K=None):
        '''
        x:    n x p
        y:    n x d true
        y0:   n x d fake 
        '''

        if self.u_func is not None:
            # two func mode
            u  = self.u_func(x, y)
            if K is not None:
            
                for k in range(K-1):

                    if k==0:
                        y0 = y0
                        g0 = self.critic(x, y0)
                    else:
                        y0 = y[torch.randperm(y.size()[0])]
                        g0 = torch.cat((g0,self.critic(x, y0)),1)

                g0_logsumexp = torch.logsumexp(g0,1).view(-1,1)
                output = u + torch.exp(-u+g0_logsumexp-g)/(K-1) - 1
            else:               
                
                g = self.critic(x, y)
                g0 = self.critic(x, y0)
               
                output = u + torch.exp(-u+g0-g) - 1
        else:
            # one func mode
            gu = self.critic(x,y)
            if isinstance(gu, tuple):
                hx,hy,u = gu
                similarity_matrix = hx @ hy.t()
                pos_mask = torch.eye(hx.size(0),dtype=torch.bool)
                g = similarity_matrix[pos_mask].view(hx.size(0),-1)
                g0 = similarity_matrix[~pos_mask].view(hx.size(0),-1)
                g0_logsumexp = torch.logsumexp(g0,1).view(-1,1)
                output = u + torch.exp(-u+g0_logsumexp-g)/(hx.size(0)-1) - 1

            else:      
                g, u = torch.chunk(self.critic(x,y),2,dim=1)
                if K is not None:

                    for k in range(K-1):

                        if k==0:
                            y0 = y0
                            g0,_ = torch.chunk(self.critic(x,y0),2,dim=1)
                        else:
                            y0 = y[torch.randperm(y.size()[0])]
                            g00,_ = torch.chunk(self.critic(x,y0),2,dim=1)
                            g0 = torch.cat((g0,g00),1)

                    g0_logsumexp = torch.logsumexp(g0,1).view(-1,1)
                    output = u + torch.exp(-u+g0_logsumexp-g)/(K-1) - 1
                else:    

                    g0, _ = torch.chunk(self.critic(x,y0),2,dim=1)
                    output = u + torch.exp(-u+g0-g) - 1
        return output
        
        
        
        
        
class BilinearCritic(nn.Module):
    
    '''
    encoder_x : dx -> feature_dim
    encoder_y : dy -> feature_dim
    u_func : 2*feature_dim -> 1
    '''
    
    def __init__(self,
                 encoder_x: nn.Module,
                 encoder_y: nn.Module,
                 u_func: nn.Module,
                 tau: Optional[float] = 1.):
        
        super(BilinearCritic,self).__init__()
        self.encoder_x = encoder_x
        self.encoder_y = encoder_y
        self.u_func = u_func
        self.tau = torch.nn.Parameter(torch.Tensor([tau]))
        
    
    def forward(self, x, y, tau=None):
        if tau is None:
            tau = self.tau
        tau = torch.sqrt(tau)
        hx = self.norm(self.encoder_x(x))
        hy = self.norm(self.encoder_y(y))
        u = self.u_func(hx,hy)
        
        return hx/tau, hy/tau, u  
    
    def norm(self,z):
        return torch.nn.functional.normalize(z,dim=1)
    
    
    
    
class FenchelInfoNCETrainer(object):
    
    def __init__(self, model):
        
        self.model = model
        
    def fit(self, train_data,sampler = None, K = None, args=None):
        
        model = self.model
        
        since = time.time()
        liveloss = PlotLosses()

        num_epochs = 10
        batch_size = 128
        lr = 1e-4
        if args is not None:
            if args.get('num_epochs'): num_epochs = args['num_epochs']
            if args.get('batch_size'): batch_size = args['batch_size']
            if args.get('lr'): lr = args['lr']
        
        
        D = model.critic
        if model.u_func is not None:    
            U = model.u_func

            #opt_D = torch.optim.Adam(params=D.parameters(),lr=lr)
            opt_D = torch.optim.Adam(params=[*D.parameters(),*U.parameters()],lr=lr)
        else:
            opt_D = torch.optim.Adam(params=D.parameters(),lr=lr)
        
        best_acc = -np.infty
        best_loss = np.infty
        best_epoch = 0
        best_model_wts = copy.deepcopy(model.state_dict())
        
        train_loader = torch.utils.data.DataLoader(
            train_data, batch_size=batch_size, shuffle=True, num_workers=1, drop_last=True)
#         val_loader = torch.utils.data.DataLoader(
#             val_data, batch_size=batch_size, shuffle=True, num_workers=1, drop_last=True)
        val_loader = []
        
        data_loaders = {'train': train_loader, 'val': val_loader}
        dataset_sizes = {'train': len(train_loader), 'val': len(val_loader)}
        loss_list = list()
        for epoch in range(num_epochs):
            if sampler is not None:
                train_data = sampler.sample(len(train_data))
                train_loader = torch.utils.data.DataLoader(
                            train_data, batch_size=batch_size, 
                            shuffle=True, num_workers=1, drop_last=True)
                
                data_loaders = {'train': train_loader, 'val': val_loader}
            

            print('Epoch {}/{}'.format(epoch+1, num_epochs))
            print('-' * 10)

            for phase in ['train']:

                if phase == 'train':
                    model.train()
                else:
                    model.eval()

                running_loss = 0.0
                running_acc = torch.Tensor([0])
        #         running_regs = [0.]*len(regs)

                for i,(x,y) in enumerate(data_loaders[phase]):
                    
                    if phase == 'train': 
                        
                
                        opt_D.zero_grad()
                        
                        ###### Modified to train logit for MI ######
                        
                    
                        y0 = y[torch.randperm(y.size()[0])]

                        
                        if K is not None:
                            
                            fnice = model(x,y,y0,K)
                        else:
                            fnice = model(x,y,y0)
                            
                        loss = fnice
                        #############################################
                        
                        target_D = loss
                        target_D.backward()
                        opt_D.step()
                    
                        

                    running_loss += target_D.item() 
            

                    print("\rIteration: {}/{}, Loss: {:.3f}\r".format(i+1, len(data_loaders[phase]), 
                                                        loss.item() ), end="")
                    sys.stdout.flush()
             
                epoch_loss = running_loss / dataset_sizes[phase]

                avg_loss = epoch_loss
        
            loss_list.append(-avg_loss)
            loss_dict = dict()
            loss_dict.update({'log loss': avg_loss})
    
        #     for j,(alph,reg,name,rnd_pair) in enumerate(regs):
        #         loss_dict.update({name: avg_regs[j], 'val_'+name: val_regs[j]})

            liveloss.update(loss_dict)

            liveloss.draw()
            
          
        time_elapsed = time.time() - since
        
        print('Training complete in {:.0f}m {:.0f}s'.format(
            time_elapsed // 60, time_elapsed % 60))
        
#         self.load()
        
        return loss_list[len(loss_list)-1], time_elapsed
    
    
class FenchelInfoNCEOne(nn.Module):
    def __init__(self,
         critic: nn.Module, 
         u_func: Optional[nn.Module] = None,
         K: Optional[int] = None,
         args: Optional[Dict] = None,
         cuda: Optional[int] = None) -> None:
        
        super(FenchelInfoNCEOne,self).__init__()
        self.critic = critic
        self.u_func = u_func
        self.K = K
    def forward(self, x, y, y0,K=None):
        
        '''
        x:    n x p
        y:    n x d true
        y0:   n x d fake 
        '''
        if K is None:
            K = self.K 
#         g = self.critic(x, y)
#         g0 = self.critic(x, y0)
#         u  = self.u_func(x, y)
#         output = u + torch.exp(-u+g0-g) - 1
        output  = self.PMI(x,y,y0,K)
        return output.mean()
    
    def MI(self, x, y, K=10):
        mi = 0
        for k in range(K):
            y0 = y[torch.randperm(y.size()[0])]
            mi += self.forward(x,y,y0)
            
        return -mi/K      
    def PMI(self, x, y, y0, K=None):
        '''
        x:    n x p
        y:    n x d true
        y0:   n x d fake 
        '''
        
        if self.u_func is not None:
            u  = self.u_func(x, y)
            if K is not None:
            
                for k in range(K-1):

                    if k==0:
                        y0 = y0
                        g0 = self.critic(x, y0)
                    else:
                        y0 = y[torch.randperm(y.size()[0])]
                        g0 = torch.cat((g0,self.critic(x, y0)),1)

                g0_logsumexp = torch.logsumexp(g0,1).view(-1,1)
                output = u + torch.exp(-u+g0_logsumexp-g)/(K-1) - 1
            else:               
                # two func mode
                g = self.critic(x, y)
                g0 = self.critic(x, y0)
                
                output = u + torch.exp(-u+g0-g) - 1
        else:
            # one func mode
            g, u = torch.chunk(self.critic(x,y),2,dim=1)
            if K is not None:
            
                for k in range(K-1):

                    if k==0:
                        y0 = y0
                        g0,_ = torch.chunk(self.critic(x,y0),2,dim=1)
                    else:
                        y0 = y[torch.randperm(y.size()[0])]
                        g00,_ = torch.chunk(self.critic(x,y0),2,dim=1)
                        g0 = torch.cat((g0,g00),1)

                g0_logsumexp = torch.logsumexp(g0,1).view(-1,1)
                output = u + torch.exp(-u+g0_logsumexp-g)/(K-1) - 1
            else:    
                
                g0, _ = torch.chunk(self.critic(x,y0),2,dim=1)
                output = u + torch.exp(-u+g0-g) - 1
        return output
        
        
        
task_id = int(sys.argv[1])
k_list = [16,32,64,100,200,300,400,500]
k = k_list[task_id]

rho = 0.5
p = 10
n = 10000
N = n*p
mu = np.array([[0,0]])
sigma = np.array([[[1,rho],[rho,1]]])
GMS = GaussianMixtureSample(mu,sigma)

args = {}
args['lr'] = 1e-3
args['latent_dim'] = 100
args['num_epochs'] = int(50*np.sqrt(k/16))
args["input_dim"] = 2*p
args['output_dim'] = 2
args['batch_size'] = k
feature_dim = 512
encoder_x = MLP(p, output_dim=feature_dim)
encoder_y = MLP(p, output_dim=feature_dim)
u_func = Wrapper(MLP(2*feature_dim,hidden_dim=[128]))
critic = BilinearCritic(encoder_x, encoder_y, u_func)
model = BilinearFenchelInfoNCEOne(critic)
mitrainer = FenchelInfoNCETrainer(model)


sampler = ToySampler(rho,p)
train_data = sampler.sample(n)
loss_bi, time_bi = mitrainer.fit(train_data, sampler = sampler, K=k,args = args)


mu = np.array([[0,0]])
sigma = np.array([[[1,rho],[rho,1]]])
GMS = GaussianMixtureSample(mu,sigma)

args = {}
args['lr'] = 1e-3
args['latent_dim'] = 100
args['num_epochs'] = 50
args["input_dim"] = 2*p
args['output_dim'] = 2
args['batch_size'] = 128

critic = Wrapper(MLP(input_dim = args["input_dim"], output_dim=args['output_dim']))
model = FenchelInfoNCEOne(critic)
mitrainer = FenchelInfoNCETrainer(model)

sampler = ToySampler(rho,p)
train_data = sampler.sample(n)
loss_one, time_one = mitrainer.fit(train_data,sampler = sampler, K=k,args = args)



result = dict()
result['bilinear_mi'] = loss_bi
result['One_mi'] = loss_one
result['bilinear_time'] = time_bi
result['time_one'] = time_one

result['k'] = k

np.save('Bilinear_%d.npy' %task_id, result)







import os
from utilities import *
import numpy as np
import sys
class FenchelInfoNCEOne(nn.Module):
    def __init__(self,
         critic: nn.Module, 
         u_func: Optional[nn.Module] = None,
         args: Optional[Dict] = None,
         cuda: Optional[int] = None) -> None:
        
        super(FenchelInfoNCEOne,self).__init__()
        self.critic = critic
        self.u_func = u_func
        
    def forward(self, x, y, y0):
        
        '''
        x:    n x p
        y:    n x d true
        y0:   n x d fake 
        '''
    
#         g = self.critic(x, y)
#         g0 = self.critic(x, y0)
#         u  = self.u_func(x, y)
#         output = u + torch.exp(-u+g0-g) - 1
        output  = self.PMI(x,y,y0)
        return output.mean()
    
    def MI(self, x, y, K=10):
        mi = 0
        for k in range(K):
            y0 = y[torch.randperm(y.size()[0])]
            mi += self.forward(x,y,y0)
            
        return -mi/K      
    def PMI(self, x, y, y0):
        '''
        x:    n x p
        y:    n x d true
        y0:   n x d fake 
        '''
        if self.u_func is not None:
            # two func mode
            g = self.critic(x, y)
            g0 = self.critic(x, y0)
            u  = self.u_func(x, y)
        else:
            # one func mode
            g, u = torch.chunk(self.critic(x,y),2,dim=1)
            g0, _ = torch.chunk(self.critic(x,y0),2,dim=1)
        output = u + torch.exp(-u+g0-g) - 1
        return output
    
    
class FenchelInfoNCETrainer(object):
    
    def __init__(self, model):
        
        self.model = model
        
    def fit(self, train_data,sampler = None, args=None):
        
        model = self.model
        
        since = time.time()
        liveloss = PlotLosses()

        num_epochs = 10
        batch_size = 128
        lr = 1e-4
        if args is not None:
            if args.get('num_epochs'): num_epochs = args['num_epochs']
            if args.get('batch_size'): batch_size = args['batch_size']
            if args.get('lr'): lr = args['lr']
        
        
        D = model.critic
        if model.u_func is not None:    
            U = model.u_func

            #opt_D = torch.optim.Adam(params=D.parameters(),lr=lr)
            opt_D = torch.optim.Adam(params=[*D.parameters(),*U.parameters()],lr=lr)
        else:
            opt_D = torch.optim.Adam(params=D.parameters(),lr=lr)
        
        best_acc = -np.infty
        best_loss = np.infty
        best_epoch = 0
        best_model_wts = copy.deepcopy(model.state_dict())
        
        train_loader = torch.utils.data.DataLoader(
            train_data, batch_size=batch_size, shuffle=True, num_workers=1, drop_last=True)
#         val_loader = torch.utils.data.DataLoader(
#             val_data, batch_size=batch_size, shuffle=True, num_workers=1, drop_last=True)
        val_loader = []
        
        data_loaders = {'train': train_loader, 'val': val_loader}
        dataset_sizes = {'train': len(train_loader), 'val': len(val_loader)}
        loss_list = list()
        for epoch in range(num_epochs):
            if sampler is not None:
                train_data = sampler.sample(len(train_data))
                train_loader = torch.utils.data.DataLoader(
                            train_data, batch_size=batch_size, 
                            shuffle=True, num_workers=1, drop_last=True)
                
                data_loaders = {'train': train_loader, 'val': val_loader}
            

            print('Epoch {}/{}'.format(epoch+1, num_epochs))
            print('-' * 10)

            for phase in ['train']:

                if phase == 'train':
                    model.train()
                else:
                    model.eval()

                running_loss = 0.0
                running_acc = torch.Tensor([0])
        #         running_regs = [0.]*len(regs)

                for i,(x,y) in enumerate(data_loaders[phase]):
                    
                    if phase == 'train': 
                        
                
                        opt_D.zero_grad()
                        
                        ###### Modified to train logit for MI ######
                        
                    
                        y0 = y[torch.randperm(y.size()[0])]

                        
                        
                        fnice = model(x,y,y0)
                        loss = fnice
                        #############################################
                        
                        target_D = loss
                        target_D.backward()
                        opt_D.step()
                    
                        

                    running_loss += target_D.item() 
            

                    print("\rIteration: {}/{}, Loss: {:.3f}\r".format(i+1, len(data_loaders[phase]), 
                                                        loss.item() ), end="")
                    sys.stdout.flush()
             
                epoch_loss = running_loss / dataset_sizes[phase]

                avg_loss = epoch_loss
        
            loss_list.append(-avg_loss)
            loss_dict = dict()
            loss_dict.update({'log loss': avg_loss})
    
        #     for j,(alph,reg,name,rnd_pair) in enumerate(regs):
        #         loss_dict.update({name: avg_regs[j], 'val_'+name: val_regs[j]})

            liveloss.update(loss_dict)

            liveloss.draw()
            
          
        time_elapsed = time.time() - since
        
        print('Training complete in {:.0f}m {:.0f}s'.format(
            time_elapsed // 60, time_elapsed % 60))
        
#         self.load()
        
        return loss_list
    
    
task_id = int(sys.argv[1])
lrlist = [1e-3,1e-4]
nlr = len(lrlist)
nr = 3
rholist = [0.2,0.5,0.8]
rho = rholist[task_id%nr]
lr = lrlist[task_id//nr]
mu = np.array([[0,0]])
sigma = np.array([[[1,rho],[rho,1]]])
GMS = GaussianMixtureSample(mu,sigma)

n = 10000
p = 10
args = {}
args['lr'] = lr
args['latent_dim'] = 100
args['num_epochs'] = 50
args["input_dim"] = 2*p
args['output_dim'] = 2

critic = Wrapper(MLP(input_dim=args["input_dim"], output_dim=args['output_dim'], hidden_dim=[]))
model = FenchelInfoNCEOne(critic)
mitrainer = FenchelInfoNCETrainer(model)


sampler = ToySampler(rho,p)
train_data = sampler.sample(n)
loss_dict_One = mitrainer.fit(train_data,sampler = sampler,args = args)





args = {}
args['lr'] = lr
args['latent_dim'] = 100
args['num_epochs'] = 50
args["input_dim"] = 2*p
args['output_dim'] = 2

critic = Wrapper(MLP(input_dim=args["input_dim"], output_dim=args['output_dim'], hidden_dim=[512]))
model = FenchelInfoNCEOne(critic)
mitrainer = FenchelInfoNCETrainer(model)


sampler = ToySampler(rho,p)
train_data = sampler.sample(n)
loss_dict_two = mitrainer.fit(train_data,sampler = sampler,args = args)


args = {}
args['lr'] = lr
args['latent_dim'] = 100
args['num_epochs'] = 50
args["input_dim"] = 2*p
args['output_dim'] = 2

critic = Wrapper(MLP(input_dim=args["input_dim"], output_dim=args['output_dim']))
model = FenchelInfoNCEOne(critic)
mitrainer = FenchelInfoNCETrainer(model)


sampler = ToySampler(rho,p)
train_data = sampler.sample(n)
loss_dict_three = mitrainer.fit(train_data,sampler = sampler,args = args)


args = {}
args['lr'] = lr
args['latent_dim'] = 100
args['num_epochs'] = 50
args["input_dim"] = 2*p
args['output_dim'] = 2
critic = Wrapper(MLP(input_dim=args["input_dim"], output_dim=args['output_dim'], hidden_dim=[512,512,512,512,512]))
model = FenchelInfoNCEOne(critic)
mitrainer = FenchelInfoNCETrainer(model)

sampler = ToySampler(rho,p)
train_data = sampler.sample(n)
loss_dict_four = mitrainer.fit(train_data,sampler = sampler,args = args)


mi = dict()
mi['loss_dict_One'] = loss_dict_One
mi['loss_dict_two'] = loss_dict_two
mi['loss_dict_three'] = loss_dict_three
mi['loss_dict_four'] = loss_dict_four

mi['rho'] = rho
mi['lr'] = lr
np.save('Fenchel_%d_%d.npy' % (task_id//nr,task_id%nr), mi)

